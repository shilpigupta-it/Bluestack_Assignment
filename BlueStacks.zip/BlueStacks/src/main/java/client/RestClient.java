package client;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import logging.LoggerHelper;

public class RestClient {

	Logger log=LoggerHelper.initailizeLogger(RestClient.class);
	
	public int get(String url) throws ClientProtocolException, IOException
	{
		CloseableHttpClient httpClient=HttpClients.createDefault();
		HttpGet httpget= new HttpGet(url);
		CloseableHttpResponse closeableHttpResponse= httpClient.execute(httpget);
		log.info("Hitting url: "+url);
		
		String responseString=EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responseJson=new JSONObject(responseString);
		JSONObject main= responseJson.getJSONObject("main");
		int temperature=(int) main.get("temp");
		return temperature;

		
	}
}

