package testbase;


import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import logging.LoggerHelper;
import propertyReader.PropertiesReader;
import utilityClasses.Utilities;
import waitHelper.WaitHelper;


public class TestBase {

	public static WebDriver driver;
	Utilities utility;
	Logger log=LoggerHelper.initailizeLogger(TestBase.class);
	
	public WaitHelper waitHelper;

	//@BeforeSuite
	public void beforeSuiteSetup()
	{
		PropertiesReader.loadProperties();
		
	}
	
	@BeforeTest
	public void beforeTest()
	{
		utility= new Utilities(driver);
		utility.inputJsonData();
		initializeBrowser();
 
	}
	
	
	@AfterTest
	public void afterTest()
	{
		closeBrowsers();

	}	
	
	
	public void initializeBrowser()
	{
		System.setProperty("webdriver.chrome.driver", ".//chromedriver.exe");
		driver=new ChromeDriver();
		log.info("Browser session is initialised");
		driver.manage().window().maximize();
		waitHelper=new WaitHelper(driver);
		waitHelper.setPageLoadTime(Long.valueOf(90));
		log.info("Page load time is set to 90");
	}
	
	public void closeBrowsers()
	{
		driver.quit();
		log.info("Closed all browser sessions");
	}
	
	public void getUrl(String url)
	{
		driver.get(url);
		log.info("Hitting url:"+ url);
		
	}
	
}
