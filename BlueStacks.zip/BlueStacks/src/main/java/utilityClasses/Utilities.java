package utilityClasses;

import java.util.HashMap;
import java.util.Scanner;

import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import propertyReader.PropertiesReader;

public class Utilities {

	WebDriver driver;
	JSONObject jsonObject;
	static double varianceValue;
	static String cityName;
	
	public Utilities(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	public void inputJsonData()
	{
		HashMap<String,String> myMap = new HashMap<String,String>();

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter City:");
        String city = sc.next();
        myMap.put("City",city);
        
        System.out.println("Enter Variance:");
        String variance = sc.next();
        myMap.put("Variance",variance);
        
        
        try {
            jsonObject = new JSONObject(myMap);
            cityName=(String) jsonObject.get("City");
            String var=(String) jsonObject.get("Variance");
    		varianceValue=Integer.parseInt(var);
            
            
        } catch (JSONException e) {
            e.printStackTrace();
        }
	}
	
	public static String getCityName()
	{
        return cityName;
	}
	
	public static double getVarianceValue()
	{
        return varianceValue;
	}
	
	public static String  getApiUrl()
	{
		String serviceUrl= PropertiesReader.getProperty("URL2")+cityName+PropertiesReader.getProperty("path");
		return serviceUrl;
	}
}
