package pageLibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchResultPage {

	WebDriver driver;
	WebDriverWait wait;
	
	public SearchResultPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="div.CurrentConditions--primary--3xWnK span")
	WebElement temperatureString;
	
	public int getTemperature()
	{
		wait=new WebDriverWait(driver,5);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.CurrentConditions--primary--3xWnK span")));
		String temp=temperatureString.getText();
		String tempInString[]=temp.split("\\u00B0");
		int temperature=Integer.parseInt(tempInString[0]);
		return temperature;
	}
}
