package pageLibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WeatherHomePage {

	WebDriver driver;
	WebDriverWait wait;
	
	public WeatherHomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="LocationSearch_input")
	WebElement searchbox;
	
	public void enterMovie(String movieName)
	{
		wait=new WebDriverWait(driver,5);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("LocationSearch_input")));
		searchbox.sendKeys(movieName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("LocationSearch_listbox")));
		searchbox.sendKeys(Keys.ARROW_DOWN);
		searchbox.sendKeys(Keys.ENTER);
	}
	
}
