package propertyReader;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

import logging.LoggerHelper;

public class PropertiesReader {
	
	static Boolean flag=false;
	static String PropFilePath=".//config.properties";
	static Properties prop;
	static Logger log=LoggerHelper.initailizeLogger(PropertiesReader.class);
	
	public static void loadProperties()
	{
	 	
	 	prop=new Properties();
	 	try {
			InputStream input=new FileInputStream(PropFilePath);
			prop.load(input);
			flag=true;

			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	 	
	}
	
	public static String getProperty(String key)
	{
		if(flag==false)
		{
			loadProperties();
		}
		return prop.getProperty(key);
		
	}
	
}
