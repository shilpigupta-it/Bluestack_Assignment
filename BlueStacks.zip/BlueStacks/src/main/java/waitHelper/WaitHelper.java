package waitHelper;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;


public class WaitHelper {

	private WebDriver driver;

	

	
	public WaitHelper(WebDriver driver)
	{
		this.driver=driver;

	}
	
	public void setPageLoadTime(long pageLoadTime)
	{
		driver.manage().timeouts().pageLoadTimeout(pageLoadTime, TimeUnit.SECONDS);
	
	}
	
	public void hardcodedWait(long timeinmillis)
	{
		try {
			Thread.sleep(timeinmillis);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
