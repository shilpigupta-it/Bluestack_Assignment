package logging;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import propertyReader.PropertiesReader;

public class LoggerHelper {

	public static boolean flag=false;
	
	public static Logger initailizeLogger(Class cls)
	{
		if (flag)
		{
			return Logger.getLogger(cls);
		}
		
		PropertyConfigurator.configure(PropertiesReader.getProperty("LogFilePath"));
		flag=true;
		return Logger.getLogger(cls);
	}
}
