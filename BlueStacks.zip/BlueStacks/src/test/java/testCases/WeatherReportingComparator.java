package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;

import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import client.RestClient;
import logging.LoggerHelper;
import pageLibrary.SearchResultPage;
import pageLibrary.WeatherHomePage;
import propertyReader.PropertiesReader;
import testbase.TestBase;
import utilityClasses.Utilities;

public class WeatherReportingComparator extends TestBase{	
		
	
	WeatherHomePage whp;
	SearchResultPage result;
	RestClient client;
	Utilities utility;
	Logger log=LoggerHelper.initailizeLogger(WeatherReportingComparator.class);
	
	@Test
	public void weatherComparator() throws java.lang.Exception
	{
		
		getUrl(PropertiesReader.getProperty("URL1"));
		whp=new WeatherHomePage(driver);
		String city=Utilities.getCityName();
		whp.enterMovie(city);
		
		result=new SearchResultPage(driver);
		int temperature1=result.getTemperature();
		log.info("Temperature received from weather.com webpage:" + temperature1);
		
		client=new RestClient();
		int temperature2 = client.get(Utilities.getApiUrl());
		log.info("Temperature received from API:" + temperature2);
		
		double difference=Math.abs(temperature1-temperature2);
		double variance= Utilities.getVarianceValue();
		
		if(difference<=variance)
		{
			Assert.assertTrue(true);
			log.info("Temperature difference is in specified range");
		}
		else
		{
			throw new Exception("Temperature difference is not in specified range");
		}
		
				
	}

	


}
